"""TravelMate Karnataka — Streamlit RAG travel assistant."""
from __future__ import annotations
import os
from pathlib import Path
import streamlit as st
from dotenv import load_dotenv

from document_processing import (
    DEFAULT_FAQ_PATH, FAQEntry, add_single_faq_entry, delete_single_faq_entry,
    load_faq_entries, save_faq_entries, update_single_faq_entry,
)
from notice_manager import (
    add_notice, delete_notice, get_active_notices, get_pinned_notices,
    load_notices, update_notice,
)
from question_manager import (
    delete_submitted_question, dismiss_question, get_pending_questions,
    load_submitted_questions, mark_question_answered, submit_question,
)
from rag_pipeline import (
    API_KEY_ERROR, GeminiResponseError, MissingAPIKeyError, RetrievalError,
    answer_question,
)
from vector_store import rebuild_index, search_faq

load_dotenv()
st.set_page_config(page_title="TravelMate Karnataka", page_icon="🧭", layout="wide")
st.markdown("""
<style>
:root { --ink:#15243b; --muted:#60718b; --accent:#0d766e; }
.block-container {max-width: 1180px; padding-top: 2rem; padding-bottom: 3rem;}
.hero {padding:2rem 2.2rem;border-radius:22px;background:linear-gradient(120deg,#102b43,#146b66);color:white;margin-bottom:1.2rem;}
.hero h1 {font-size:2.5rem;margin:0 0 .4rem 0;color:white}
.hero p {color:#d9f1ed;font-size:1.05rem;margin:0}
.small-muted {color:#60718b;font-size:.9rem}
.source-card {padding:.8rem 1rem;border:1px solid #dce5e9;border-radius:12px;margin:.5rem 0;background:#fbfdfd}
.notice-card {padding:1rem;border:1px solid #e2e8f0;border-left:4px solid #0d766e;border-radius:12px;margin:.6rem 0}
div[data-testid="stChatMessage"] {border-radius:14px}
</style>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner="Loading semantic embedding model…")
def warmup_index():
    return rebuild_index()

def refresh_index():
    warmup_index.clear()
    return warmup_index()

def render_sources(sources):
    for i, source in enumerate(sources, 1):
        with st.expander(f"Source {i}: {source.question} · {source.similarity:.0%} match"):
            st.caption(f"{source.source} · {source.category}")
            st.write(source.content)

def chat_tab():
    st.subheader("Ask the Karnataka travel assistant")
    st.caption("Answers are generated using retrieved TravelMate knowledge-base passages (RAG). Sources are shown with every grounded answer.")
    if "messages" not in st.session_state: st.session_state.messages=[]
    for m in st.session_state.messages:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
            if m.get("sources"): render_sources(m["sources"])
    prompt=st.chat_input("Ask about Karnataka destinations, itineraries, food, travel planning…")
    if prompt:
        st.session_state.messages.append({"role":"user","content":prompt})
        with st.chat_message("user"): st.markdown(prompt)
        with st.chat_message("assistant"):
            try:
                with st.spinner("Searching the travel knowledge base and generating an answer…"):
                    result=answer_question(prompt,allow_extractive_fallback=True)
                st.markdown(result.answer)
                if result.is_extractive_fallback: st.info("Showing a direct retrieved answer because Gemini generation was unavailable.")
                elif result.model_used: st.caption(f"Generated with {result.model_used} · grounded in retrieved sources")
                render_sources(result.sources)
                st.session_state.messages.append({"role":"assistant","content":result.answer,"sources":result.sources})
            except MissingAPIKeyError:
                msg=f"🔑 {API_KEY_ERROR} Create a `.env` file using `.env.example`, then restart the app."
                st.warning(msg); st.session_state.messages.append({"role":"assistant","content":msg})
            except RetrievalError as e:
                st.error(str(e))
            except GeminiResponseError as e:
                st.error(f"Gemini is unavailable: {e.details}")
                render_sources(e.sources)
                st.info("Check your API key, model quota, and internet connection.")
    c1,c2=st.columns([1,5])
    with c1:
        if st.button("Clear chat"): st.session_state.messages=[]; st.rerun()

def explore_tab():
    st.subheader("Explore Karnataka")
    destinations=[
      ("Mysuru","Palaces, heritage, gardens and local cuisine","Culture"),
      ("Hampi","Vijayanagara heritage landscape and monuments","Heritage"),
      ("Coorg (Kodagu)","Coffee-growing hills, viewpoints and nature","Nature"),
      ("Chikkamagaluru","Western Ghats scenery and coffee country","Nature"),
      ("Gokarna","Coastal scenery and beaches","Coast"),
      ("Udupi","Temple town and coastal food traditions","Culture"),
      ("Badami","Rock-cut cave temples and historic architecture","Heritage"),
      ("Mangaluru","Coastal city, cuisine and nearby attractions","Coast"),
    ]
    cols=st.columns(4)
    for i,(name,desc,tag) in enumerate(destinations):
        with cols[i%4]:
            st.markdown(f"""<div class="source-card"><div style="font-size:1.3rem;font-weight:700">{name}</div><div class="small-muted">{tag}</div><p>{desc}</p></div>""",unsafe_allow_html=True)
    st.info("Destination descriptions are general planning guidance. Confirm current access, weather, prices, opening hours and transport with official providers.")

def search_tab():
    st.subheader("Semantic travel knowledge search")
    query=st.text_input("Search the TravelMate knowledge base",placeholder="e.g. family trip to Mysuru in December")
    top_k=st.slider("Number of passages",1,8,4)
    if st.button("Search knowledge base",type="primary",disabled=not query.strip()):
        try:
            with st.spinner("Finding semantically similar travel passages…"):
                results=search_faq(query,top_k=top_k)
            if not results: st.warning("No relevant passages found.")
            for i,r in enumerate(results,1):
                st.markdown(f"**{i}. {r.question}**")
                st.caption(f"{r.source} · {r.category} · similarity {r.similarity:.1%}")
                st.write(r.content)
                st.progress(max(0,min(1,r.similarity)))
        except Exception as e: st.error(f"Search failed: {e}")

def updates_tab():
    st.subheader("Travel updates and safety reminders")
    notices=get_active_notices()
    pinned=get_pinned_notices()
    if pinned:
        st.markdown("#### Pinned reminders")
        for n in pinned:
            st.markdown(f'<div class="notice-card"><b>📌 {n.title}</b><br>{n.content}</div>',unsafe_allow_html=True)
    st.markdown("#### All updates")
    if not notices: st.info("No active updates.")
    for n in notices:
        with st.expander(f"{n.title} · {n.category}"):
            st.write(n.content); st.caption(f"Posted {n.posted_date} · {n.priority} · {n.target_audience}")

def ask_tab():
    st.subheader("Ask a question for the TravelMate knowledge base")
    with st.form("question_form"):
        question=st.text_area("Your question",placeholder="What is the best way to plan a 4-day trip from Mysuru to Coorg?")
        name=st.text_input("Name (optional)")
        category=st.selectbox("Category",["Trip planning","Destinations","Transport","Food","Safety","Other"])
        sent=st.form_submit_button("Submit question",type="primary")
    if sent:
        if len(question.strip())<8: st.error("Please enter a little more detail.")
        else:
            submit_question(question.strip(),submitted_by=name.strip() or "Traveler",category=category)
            st.success("Your question has been submitted for review.")

def admin_tab():
    st.subheader("TravelMate administration")
    if "admin_auth" not in st.session_state: st.session_state.admin_auth=False
    if not st.session_state.admin_auth:
        with st.form("admin_login"):
            password=st.text_input("Admin password",type="password")
            login=st.form_submit_button("Sign in")
        if login:
            expected=os.getenv("ADMIN_PASSWORD","")
            if expected and password==expected: st.session_state.admin_auth=True; st.rerun()
            st.error("Incorrect password or ADMIN_PASSWORD is not configured in .env.")
        return
    if st.button("Sign out"): st.session_state.admin_auth=False; st.rerun()
    faq_col,notice_col,question_col=st.tabs(["📚 Knowledge base","📢 Notices","❓ Traveler questions"])
    with faq_col:
        entries=load_faq_entries()
        st.write(f"**{len(entries)} knowledge entries**")
        with st.form("add_faq"):
            q=st.text_input("Question"); a=st.text_area("Answer"); cat=st.text_input("Category",value="Trip planning")
            if st.form_submit_button("Add knowledge entry"):
                if q.strip() and a.strip():
                    add_single_faq_entry(q,a,cat); refresh_index(); st.success("Added and re-indexed."); st.rerun()
                else: st.error("Question and answer are required.")
        for i,e in enumerate(entries):
            with st.expander(f"{i+1}. {e.question}"):
                nq=st.text_input("Question",e.question,key=f"q{i}")
                na=st.text_area("Answer",e.answer,key=f"a{i}")
                if st.button("Save changes",key=f"save{i}"):
                    update_single_faq_entry(i,nq,na,e.category); refresh_index(); st.success("Updated."); st.rerun()
                if st.button("Delete",key=f"del{i}"):
                    delete_single_faq_entry(i); refresh_index(); st.warning("Deleted."); st.rerun()
        if st.button("Rebuild semantic index"): 
            with st.spinner("Rebuilding embeddings and ChromaDB index…"): count=refresh_index()
            st.success(f"Indexed {count} passages.")
    with notice_col:
        with st.form("new_notice"):
            title=st.text_input("Notice title"); content=st.text_area("Details")
            category=st.selectbox("Category",["Travel Safety","Transport","Planning","Destination Update","Responsible Travel"])
            priority=st.selectbox("Priority",["Normal","Important","Urgent"])
            pinned=st.checkbox("Pin this notice")
            if st.form_submit_button("Publish notice"):
                if title.strip() and content.strip():
                    add_notice(title,content,category,priority,pinned); refresh_index(); st.success("Published."); st.rerun()
                else: st.error("Title and details are required.")
        for n in load_notices():
            with st.expander(n.title):
                st.write(n.content); st.caption(f"{n.category} · {n.priority}")
                c1,c2=st.columns(2)
                with c1:
                    if st.button("Deactivate" if n.is_active else "Activate",key=f"active{n.id}"):
                        update_notice(n.id,is_active=not n.is_active); refresh_index(); st.rerun()
                with c2:
                    if st.button("Delete notice",key=f"ndel{n.id}"):
                        delete_notice(n.id); refresh_index(); st.rerun()
    with question_col:
        questions=load_submitted_questions()
        if not questions: st.info("No submitted questions.")
        for q in questions:
            with st.expander(f"{q.status}: {q.question}"):
                st.caption(f"Submitted by {q.submitted_by} · {q.category} · {q.submitted_date}")
                if q.answer: st.write(q.answer)
                answer=st.text_area("Response",key=f"resp{q.id}")
                c1,c2,c3=st.columns(3)
                with c1:
                    if st.button("Mark answered",key=f"ans{q.id}") and answer.strip():
                        mark_question_answered(q.id,answer); st.success("Answered."); st.rerun()
                with c2:
                    if st.button("Dismiss",key=f"dis{q.id}"): dismiss_question(q.id); st.rerun()
                with c3:
                    if st.button("Delete",key=f"qdel{q.id}"): delete_submitted_question(q.id); st.rerun()

st.markdown('<div class="hero"><h1>🧭 TravelMate Karnataka</h1><p>Your AI-powered companion for discovering Karnataka — grounded in a curated travel knowledge base.</p></div>',unsafe_allow_html=True)
with st.sidebar:
    st.markdown("## 🧭 TravelMate")
    st.caption("Karnataka travel • Retrieval-Augmented Generation")
    st.markdown("---")
    st.markdown("**RAG pipeline**")
    st.caption("Question → semantic embedding → ChromaDB retrieval → Gemini grounded generation → cited passages")
    if st.button("Warm up / rebuild knowledge index",use_container_width=True):
        try:
            with st.spinner("Embedding travel guide entries…"): count=refresh_index()
            st.success(f"{count} passages indexed.")
        except Exception as e: st.error(str(e))
    st.caption("The first semantic search builds the index automatically.")
tabs=st.tabs(["💬 AI Assistant","🗺️ Explore","🔎 Knowledge Search","📢 Travel Updates","❓ Ask a Question","🔐 Admin"])
with tabs[0]: chat_tab()
with tabs[1]: explore_tab()
with tabs[2]: search_tab()
with tabs[3]: updates_tab()
with tabs[4]: ask_tab()
with tabs[5]: admin_tab()
st.markdown("---")
st.caption("TravelMate provides general planning information, not live booking or emergency services. Always confirm time-sensitive details with official providers.")
