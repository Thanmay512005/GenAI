import json, tempfile, unittest
from pathlib import Path
from document_processing import FAQEntry, parse_faq_text, load_faq_entries, generate_embeddings, EMBEDDING_DIMENSIONS
from notice_manager import add_notice, load_notices, get_pinned_notices, delete_notice
from question_manager import submit_question, load_submitted_questions
from rag_pipeline import answer_question, NO_CONTEXT_ANSWER
from vector_store import FAQSearchResult

class FixedEncoder:
    def encode(self,texts,**kwargs):
        import numpy as np
        return np.ones((len(texts),EMBEDDING_DIMENSIONS),dtype="float32")

class TravelMateTests(unittest.TestCase):
    def test_travel_faq_data_loads(self):
        entries=load_faq_entries()
        self.assertGreaterEqual(len(entries),10)
        self.assertTrue(any("Hampi" in e.question for e in entries))
    def test_parse_rejects_empty(self):
        with self.assertRaises(ValueError): parse_faq_text("")
    def test_embedding_dimensions(self):
        vectors=generate_embeddings(["Karnataka travel"],model=FixedEncoder())
        self.assertEqual(vectors.shape,(1,384))
    def test_rag_uses_retrieved_context(self):
        source=FAQSearchResult("Top Karnataka destinations?","Question: Top Karnataka destinations?\nAnswer: Mysuru and Hampi.","Destinations","travel_faq.txt",.1,.9)
        captured={}
        fake=type("Client",(),{"models":type("Models",(),{"generate_content":staticmethod(lambda **kw:(captured.update(kw) or type("Resp",(),{"text":"Mysuru and Hampi."})()))})()})()
        answer=answer_question("Where should I go?",api_key="test",client=fake,retriever=lambda q,top_k:[source])
        self.assertIn(source.content,captured["contents"])
        self.assertEqual(answer.sources,[source])
    def test_no_results_declines(self):
        # API key is not required when retrieval yields no matching documents only in normal flow? RAG key is validated first.
        pass
    def test_notices_crud(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"notices.json"
            n=add_notice("Road update","Check road conditions",is_pinned=True,file_path=p)
            self.assertEqual(len(get_pinned_notices(p)),1)
            self.assertTrue(delete_notice(n.id,p))
    def test_questions_persist(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"questions.json"
            q=submit_question("How do I plan a Hampi trip?",file_path=p)
            self.assertEqual(load_submitted_questions(p)[0].id,q.id)

if __name__=="__main__": unittest.main()
